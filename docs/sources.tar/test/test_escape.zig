const std = @import("std");
pub fn main() !void {
    var esc_buf: [6]u8 = undefined;
    _ = std.fmt.bufPrint(&esc_buf, "\\u{X:0>4}", .{@as(u8, 0x01)}) catch return;
    std.debug.print("result: '{s}'\n", .{&esc_buf});
    _ = std.fmt.bufPrint(&esc_buf, "\\u{X:0>4}", .{@as(u8, 0x1F)}) catch return;
    std.debug.print("result: '{s}'\n", .{&esc_buf});
}
