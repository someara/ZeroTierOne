const std = @import("std");

fn hexToBytes(comptime hex: []const u8, buf: []u8) void {
    var i: usize = 0;
    while (i < hex.len) : (i += 2) {
        buf[i / 2] = std.fmt.parseInt(u8, hex[i..i+2], 16) catch unreachable;
    }
}

pub fn main() !void {
    var parsed: [64]u8 = undefined;
    hexToBytes("00112233445566778899aabbccddeeff102132435465768798a9bacbdcedfe0f2031425364758697a8b9cadbecfd0e1f30415263748596a7b8c9daebfc0d1e2f", &parsed);
    
    var generated: [64]u8 = undefined;
    for (&generated, 0..) |*b, i| {
        b.* = @intCast((i * 17) & 0xff);
    }
    
    std.debug.print("Parsed:    ", .{});
    for (parsed) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
    
    std.debug.print("Generated: ", .{});
    for (generated) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
    
    if (std.mem.eql(u8, &parsed, &generated)) {
        std.debug.print("MATCH!\n", .{});
    } else {
        std.debug.print("MISMATCH!\n", .{});
        for (0..64) |i| {
            if (parsed[i] != generated[i]) {
                std.debug.print("  Byte {}: parsed={x:0>2} generated={x:0>2}\n", .{i, parsed[i], generated[i]});
            }
        }
    }
}
