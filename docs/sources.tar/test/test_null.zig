const std = @import("std");

pub fn main() !void {
    // In Zig, {s} format for []const u8 outputs all bytes, including nulls.
    // But the visual representation may hide them.
    // The key question: does bufPrint("{s}/{s}", .{a, b}) include nulls in the result?
    const id: []const u8 = &[_]u8{ 'f', 'o', 'o', 0, 'b', 'a', 'r' };
    var buf: [64]u8 = undefined;
    const result = std.fmt.bufPrint(&buf, "/run/{s}/", .{id}) catch unreachable;
    // Check if null byte is at index 9 (after /run/foo)
    var nbuf: [8]u8 = undefined;
    const n = std.fmt.bufPrint(&nbuf, "{d}", .{result.len}) catch unreachable;
    _ = std.posix.write(1, "len=") catch {};
    _ = std.posix.write(1, n) catch {};
    _ = std.posix.write(1, "\n") catch {};
    if (result.len > 9 and result[9] == 0) {
        _ = std.posix.write(1, "has null at 9\n") catch {};
    }
    // Write bytes as hex
    for (result) |b| {
        var hbuf: [3]u8 = undefined;
        const h = std.fmt.bufPrint(&hbuf, "{x:0>2} ", .{b}) catch unreachable;
        _ = std.posix.write(1, h) catch {};
    }
    _ = std.posix.write(1, "\n") catch {};
}
