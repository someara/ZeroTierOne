const std = @import("std");

pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();
    
    // Try the struct literal syntax
    var list: std.ArrayList(u8) = .{ .allocator = allocator, .items = &.{}, .capacity = 0 };
    defer list.deinit();
}
