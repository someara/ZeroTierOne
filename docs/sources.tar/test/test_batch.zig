const std = @import("std");

// Test if processing 4 blocks at once helps compiler optimize
fn process_single(data: []u8, key: [16]u8) void {
    for (0..data.len) |i| {
        data[i] ^= key[i % 16];
    }
}

fn process_batch4(data: []u8, key: [16]u8) void {
    var i: usize = 0;
    while (i + 64 <= data.len) : (i += 64) {
        // Process 4x16 bytes at once
        for (0..16) |j| {
            data[i + j] ^= key[j];
            data[i + 16 + j] ^= key[j];
            data[i + 32 + j] ^= key[j];
            data[i + 48 + j] ^= key[j];
        }
    }
    // Handle remainder
    while (i < data.len) : (i += 1) {
        data[i] ^= key[i % 16];
    }
}

pub fn main() !void {
    const size = 8192;
    var data1 = try std.heap.page_allocator.alloc(u8, size);
    var data2 = try std.heap.page_allocator.alloc(u8, size);
    defer std.heap.page_allocator.free(data1);
    defer std.heap.page_allocator.free(data2);
    
    @memset(data1, 0xAA);
    @memset(data2, 0xAA);
    const key = [_]u8{0x42} ** 16;
    
    const iterations = 100000;
    
    // Benchmark single
    const start1 = std.time.nanoTimestamp();
    for (0..iterations) |_| {
        process_single(data1, key);
    }
    const elapsed1 = std.time.nanoTimestamp() - start1;
    
    // Benchmark batch
    const start2 = std.time.nanoTimestamp();
    for (0..iterations) |_| {
        process_batch4(data2, key);
    }
    const elapsed2 = std.time.nanoTimestamp() - start2;
    
    const throughput1 = @as(f64, @floatFromInt(size * iterations)) / @as(f64, @floatFromInt(elapsed1)) * 1e9 / 1048576.0;
    const throughput2 = @as(f64, @floatFromInt(size * iterations)) / @as(f64, @floatFromInt(elapsed2)) * 1e9 / 1048576.0;
    
    std.debug.print("Single: {d:.2} MiB/s\n", .{throughput1});
    std.debug.print("Batch4: {d:.2} MiB/s\n", .{throughput2});
    std.debug.print("Speedup: {d:.2}x\n", .{throughput2 / throughput1});
}
