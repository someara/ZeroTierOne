const std = @import("std");

pub fn main() !void {
    // Test key0 generation
    var key0_gen: [32]u8 = undefined;
    for (&key0_gen, 0..) |*b, i| {
        b.* = @intCast((i * 3) & 0xff);
    }
    
    std.debug.print("Generated key0 (i*3): ", .{});
    for (key0_gen) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
    
    std.debug.print("Expected hex:         000306090c0f1215181b1e2124272a2d303336393c3f4245484b4e5154575a5d\n", .{});
    
    // Verify each byte
    const expected_hex = "000306090c0f1215181b1e2124272a2d303336393c3f4245484b4e5154575a5d";
    var expected: [32]u8 = undefined;
    for (0..32) |i| {
        const hex_offset = i * 2;
        expected[i] = std.fmt.parseInt(u8, expected_hex[hex_offset..hex_offset+2], 16) catch unreachable;
    }
    
    if (std.mem.eql(u8, &key0_gen, &expected)) {
        std.debug.print("✓ key0 generation matches!\n", .{});
    } else {
        std.debug.print("✗ MISMATCH in key0!\n", .{});
        for (0..32) |i| {
            if (key0_gen[i] != expected[i]) {
                std.debug.print("  Byte {}: gen={x:0>2} exp={x:0>2}\n", .{i, key0_gen[i], expected[i]});
            }
        }
    }
}
