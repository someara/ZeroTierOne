const std = @import("std");

fn hexToBytes(comptime hex: []const u8, buf: []u8) void {
    var i: usize = 0;
    while (i < hex.len) : (i += 2) {
        buf[i / 2] = std.fmt.parseInt(u8, hex[i..i+2], 16) catch unreachable;
    }
}

pub fn main() !void {
    var key0: [32]u8 = undefined;
    var key1: [32]u8 = undefined;
    hexToBytes("000306090c0f1215181b1e2124272a2d303336393c3f4245484b4e5154575a5d", &key0);
    hexToBytes("000b16212c37424d58636e79848f9aa5b0bbc6d1dce7f2fd08131e29343f4a55", &key1);
    
    std.debug.print("Test 2 parsed key0: ", .{});
    for (key0) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
    
    std.debug.print("Test 2 parsed key1: ", .{});
    for (key1) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
    
    var plaintext: [64]u8 = undefined;
    hexToBytes("00112233445566778899aabbccddeeff102132435465768798a9bacbdcedfe0f2031425364758697a8b9cadbecfd0e1f30415263748596a7b8c9daebfc0d1e2f", &plaintext);
    
    std.debug.print("Test 2 parsed plaintext: ", .{});
    for (plaintext) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
}
