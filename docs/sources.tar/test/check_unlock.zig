const std = @import("std");
pub fn main() !void {
    const f = try std.fs.cwd().createFile("/tmp/test_lock", .{ .read = true });
    defer f.close();
    const R = @TypeOf(f.unlock());
    @compileLog(R);
}
