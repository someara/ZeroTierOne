const std = @import("std");

pub fn main() !void {
    // Test: does bufPrint with {x:0>4} produce lowercase hex?
    // JSON spec requires lowercase in \uXXXX
    var buf: [6]u8 = undefined;
    const ch: u8 = 0x0a; // already handled by \n, but test format
    const result = std.fmt.bufPrint(&buf, "\\u{x:0>4}", .{ch}) catch unreachable;
    _ = std.posix.write(1, result) catch {};
    _ = std.posix.write(1, "\n") catch {};

    // Now test: {X:0>4} for uppercase
    var buf2: [6]u8 = undefined;
    const result2 = std.fmt.bufPrint(&buf2, "\\u{X:0>4}", .{ch}) catch unreachable;
    _ = std.posix.write(1, result2) catch {};
    _ = std.posix.write(1, "\n") catch {};
}
