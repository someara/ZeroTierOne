const std = @import("std");

pub fn main() !void {
    // Test: what happens with a path traversal id?
    var dir_buf: [512]u8 = undefined;
    const id = "../../../etc";
    const STATE_DIR = "/run/buildkit-runc";
    const dir_path = std.fmt.bufPrint(&dir_buf, "{s}/{s}", .{ STATE_DIR, id }) catch unreachable;
    _ = std.posix.write(1, dir_path) catch {};
    _ = std.posix.write(1, "\n") catch {};
    
    // Test: null byte in id
    const id2 = "foo\x00bar";
    const dir_path2 = std.fmt.bufPrint(&dir_buf, "{s}/{s}", .{ STATE_DIR, id2 }) catch unreachable;
    _ = std.posix.write(1, dir_path2) catch {};
    _ = std.posix.write(1, "\n") catch {};
}
