const std = @import("std");

pub fn main() !void {
    // Test what "\\u{X:0>4}" produces for ch = 0x01
    var esc_buf: [6]u8 = undefined;
    const ch: u8 = 0x01;
    const result = std.fmt.bufPrint(&esc_buf, "\\u{X:0>4}", .{ch}) catch return;
    std.debug.print("result: '{s}' len={d}\n", .{result, result.len});
    for (result) |c| {
        std.debug.print("  byte: 0x{X:0>2} '{c}'\n", .{c, c});
    }
    
    // Also test ch = 0x1F
    const ch2: u8 = 0x1F;
    const result2 = std.fmt.bufPrint(&esc_buf, "\\u{X:0>4}", .{ch2}) catch return;
    std.debug.print("result2: '{s}' len={d}\n", .{result2, result2.len});
}
