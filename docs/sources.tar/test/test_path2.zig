const std = @import("std");

pub fn main() !void {
    // Verify: bufPrint with {s} on a string containing \x00 — does it stop at null?
    const id = "foo\x00bar";
    _ = std.posix.write(1, "id len: ") catch {};
    var lbuf: [8]u8 = undefined;
    const l = std.fmt.bufPrint(&lbuf, "{d}", .{id.len}) catch unreachable;
    _ = std.posix.write(1, l) catch {};
    _ = std.posix.write(1, "\n") catch {};

    var buf: [64]u8 = undefined;
    const result = std.fmt.bufPrint(&buf, "/run/buildkit-runc/{s}/state.json", .{id}) catch unreachable;
    _ = std.posix.write(1, "path len: ") catch {};
    const l2 = std.fmt.bufPrint(&lbuf, "{d}", .{result.len}) catch unreachable;
    _ = std.posix.write(1, l2) catch {};
    _ = std.posix.write(1, "\n") catch {};
    _ = std.posix.write(1, result) catch {};
    _ = std.posix.write(1, "\n") catch {};
}
