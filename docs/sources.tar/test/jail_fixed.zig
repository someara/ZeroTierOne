// FreeBSD Jail lifecycle management
//
// Wraps the jail(2) API for creating, querying, and destroying jails.
// Uses FreeBSD 16 jail descriptors for automatic cleanup — closing an
// owning descriptor removes the jail.
//
// Reference: sys/sys/jail.h, lib/libjail/jail.h, kern/kern_jail.c

const std = @import("std");
const builtin = @import("builtin");
const jail_mounts = @import("jail_mounts.zig");

const log = std.log.scoped(.jail);

// ============================================================
// FreeBSD jail constants
// ============================================================

// Flags for jail_set() and jail_get() — from sys/sys/jail.h
pub const JAIL_CREATE: c_int = 0x01;
pub const JAIL_UPDATE: c_int = 0x02;
pub const JAIL_ATTACH: c_int = 0x04;
pub const JAIL_DYING: c_int = 0x08;

// FreeBSD 16+ jail descriptor flags
pub const JAIL_USE_DESC: c_int = 0x10;
pub const JAIL_AT_DESC: c_int = 0x20;
pub const JAIL_GET_DESC: c_int = 0x40;
pub const JAIL_OWN_DESC: c_int = 0x80;

pub const JAIL_SET_MASK: c_int = 0xff;
pub const JAIL_GET_MASK: c_int = 0xf8;

// Jail sysctl types for allow.* parameters
pub const JAIL_SYS_DISABLE: c_int = 0;
pub const JAIL_SYS_NEW: c_int = 1;
pub const JAIL_SYS_INHERIT: c_int = 2;

// ============================================================
// kevent constants for jail monitoring — FreeBSD 16+
// ============================================================

pub const EVFILT_JAIL: i16 = -14;
pub const EVFILT_JAILDESC: i16 = -15;

pub const NOTE_JAIL_CHILD: u32 = 0x80000000;
pub const NOTE_JAIL_SET: u32 = 0x40000000;
pub const NOTE_JAIL_ATTACH: u32 = 0x20000000;
pub const NOTE_JAIL_REMOVE: u32 = 0x10000000;
pub const NOTE_JAIL_MULTI: u32 = 0x08000000;
pub const NOTE_JAIL_CTRLMASK: u32 = 0xf0000000;

// ============================================================
// Platform-conditional extern declarations
// ============================================================

const is_freebsd = builtin.os.tag == .freebsd;

/// Read the C library's thread-local errno value.
/// C library functions (jail_set, nmount, etc.) return -1 on error and set
/// errno in thread-local storage. std.posix.errno() interprets raw syscall
/// return values (negated errno encoded in the return value), which is WRONG
/// for C library wrappers — it would always report EPERM (errno 1) because
/// @bitCast(-1) to isize triggers the "negated errno" path with value 1.
const getErrno = if (is_freebsd) getErrnoImpl else getErrnoStub;

fn getErrnoImpl() std.posix.E {
    return @enumFromInt(std.c._errno().*);
}

fn getErrnoStub() std.posix.E {
    return .SUCCESS; // stub for non-FreeBSD builds
}

// jail(2) syscalls — linked from libc on FreeBSD
const c = if (is_freebsd) struct {
    // jail_set takes mutable iovecs because the kernel writes back into
    // some buffers (desc, errmsg) via copyout(). Using iovec_const would
    // be UB for those write-back parameters.
    extern "c" fn jail_set(iov: [*]std.posix.iovec, niov: c_uint, flags: c_int) c_int;
    extern "c" fn jail_get(iov: [*]std.posix.iovec, niov: c_uint, flags: c_int) c_int;
    extern "c" fn jail_remove(jid: c_int) c_int;
    extern "c" fn jail_attach(jid: c_int) c_int;
    // FreeBSD 16+
    extern "c" fn jail_attach_jd(jd: c_int) c_int;
    extern "c" fn jail_remove_jd(jd: c_int) c_int;
} else struct {};


// ============================================================
// iovec parameter builder
// ============================================================

/// A key-value parameter for jail_set()/jail_get().
/// The jail API uses an array of iovec pairs: [name, value, name, value, ...].
pub const JailParam = struct {
    name: [:0]const u8,
    value: []const u8,
};

/// Maximum number of iovec pairs we support (name + value = 2 iovecs each).
const MAX_PARAMS = 64;

/// Build an iovec array from jail parameters.
/// Each param becomes two iovecs: one for the name (null-terminated),
/// one for the value.
///
/// Uses mutable iovec (not iovec_const) because jail_set() writes back
/// into certain buffers (desc, errmsg) via copyout(). The @constCast
/// on read-only inputs is safe because the kernel only reads those params.
fn buildIovecs(params: []const JailParam, iovecs: *[MAX_PARAMS * 2]std.posix.iovec) usize {
    std.debug.assert(params.len <= MAX_PARAMS);
    var i: usize = 0;
    for (params) |p| {
        // Name iovec — include null terminator
        iovecs[i] = .{
            .base = @constCast(p.name.ptr),
            .len = p.name.len + 1, // include \0
        };
        i += 1;
        // Value iovec
        iovecs[i] = .{
            .base = @constCast(p.value.ptr),
            .len = p.value.len,
        };
        i += 1;
    }
    return i;
}

// ============================================================
// Jail configuration
// ============================================================

/// VNET (virtual network stack) mode for jail creation.
pub const VnetMode = enum {
    /// Create a new VNET for this jail (JAIL_SYS_NEW).
    /// Used for pod jails that own their network namespace.
    new,
    /// Inherit the parent jail's VNET (JAIL_SYS_INHERIT).
    /// Used for container jails that share the pod's network.
    /// Note: omitting the "vnet" parameter entirely also inherits,
    /// but explicit inherit is clearer for documentation.
    inherit,
    /// No VNET — use the host's network stack.
    /// This is the traditional jail networking mode.
    disabled,
};

/// Linux binary compatibility (Linuxulator) mode for jail creation.
pub const LinuxMode = enum {
    /// Create a new Linux emulation environment for this jail (JAIL_SYS_NEW).
    /// The jail gets its own linux.osname, linux.osrelease, etc.
    new,
    /// Inherit the parent jail's Linux emulation environment (JAIL_SYS_INHERIT).
    inherit,
    /// No Linux compatibility — Linux binaries cannot run (default).
    disabled,
};

/// Configuration for creating a new jail.
pub const JailConfig = struct {
    /// Jail name (also used as hostname if hostname is null).
    /// For child jails, use dotted notation: "parent-name.child-name".
    /// The kernel determines the parent jail from the name prefix.
    name: [:0]const u8,
    /// Root filesystem path for the jail.
    /// Pod jails (network namespace only) typically use "/".
    /// Container jails use the ZFS-backed rootfs path.
    path: [:0]const u8,
    /// Hostname (defaults to name if null).
    hostname: ?[:0]const u8 = null,
    /// VNET mode: new (own network stack), inherit (parent's), or disabled.
    /// Pod jails use .new, container jails use .inherit.
    vnet: VnetMode = .new,
    /// Maximum number of child jails allowed. null = kernel default (0).
    /// Pod jails MUST set this to at least the number of containers.
    /// Child jails' children_max must be strictly less than their parent's.
    children_max: ?u32 = null,
    /// Keep jail alive even with no running processes.
    /// Required for pod jails (pure network namespace containers) and
    /// for container jails between creation and process exec.
    persist: bool = true,
    /// Allow raw sockets inside the jail (needed for ping, etc.).
    allow_raw_sockets: bool = false,
    /// Allow mounting filesystems inside the jail.
    allow_mount: bool = false,
    /// Allow mounting ZFS inside the jail.
    allow_mount_zfs: bool = false,
    /// Allow mounting nullfs (bind mounts) inside the jail.
    /// Required for BuildKit and similar container build tools.
    allow_mount_nullfs: bool = false,
    /// Allow mounting devfs inside the jail.
    allow_mount_devfs: bool = true,
    /// Allow setting hostname inside the jail.
    allow_set_hostname: bool = true,
    /// Allow mounting linprocfs inside the jail (for Linux compat).
    allow_mount_linprocfs: bool = false,
    /// Allow mounting linsysfs inside the jail (for Linux compat).
    allow_mount_linsysfs: bool = false,
    /// Allow mounting fdescfs inside the jail (for Linux compat /dev/fd).
    allow_mount_fdescfs: bool = false,
    /// Allow mounting tmpfs inside the jail (for Linux compat /dev/shm).
    allow_mount_tmpfs: bool = false,
    /// Linux binary compatibility mode.
    /// .new = own Linux emulation environment (JAIL_SYS_NEW).
    /// .inherit = inherit parent's Linux environment.
    /// .disabled = no Linux compat (default).
    linux: LinuxMode = .disabled,
    /// Linux osrelease string reported to Linux binaries (e.g., "5.15.0").
    /// Only used when linux != .disabled.
    linux_osrelease: ?[:0]const u8 = null,
    /// enforce_statfs level (0-2). Default 2 prevents in-jail mount visibility.
    /// Set to 1 for Linux compat (required for in-jail linprocfs/linsysfs mounts).
    /// null = omit parameter (use kernel default of 2).
    enforce_statfs: ?u32 = null,
    /// Use owning jail descriptor (close fd = auto-remove jail).
    /// Requires FreeBSD 16+.
    use_owning_descriptor: bool = true,
    /// Devfs ruleset number for in-jail devfs mounts.
    /// Ruleset 4 = devfsrules_jail (standard: null, zero, random, urandom, pts, etc.)
    /// Ruleset 0 = no restriction (not recommended for jails).
    devfs_ruleset: c_int = 4,
    /// OCI annotations to store as jail metadata (meta.* namespace).
    annotations: []const Annotation = &.{},

    pub const Annotation = struct {
        key: [:0]const u8,
        value: [:0]const u8,
    };
};

// ============================================================
// Jail handle
// ============================================================

/// Represents a running jail. If created with an owning descriptor,
/// closing the handle automatically removes the jail.
pub const Jail = struct {
    /// Jail ID (kernel-assigned).
    jid: c_int,
    /// Jail descriptor fd (FreeBSD 16+). -1 if not using descriptors.
    descriptor: c_int = -1,
    /// Whether this is an owning descriptor.
    owning: bool = false,
    /// The jail name.
    name: [:0]const u8,

    /// Remove the jail and release resources.
    /// Safe to call multiple times — subsequent calls are no-ops.
    pub const destroy = if (is_freebsd) destroyImpl else destroyStub;

    fn destroyImpl(self: *Jail) JailError!void {
        if (self.owning and self.descriptor >= 0) {
            // Closing an owning descriptor auto-removes the jail
            std.posix.close(self.descriptor);
            self.descriptor = -1;
            log.info("jail '{s}' (jid={d}) removed via descriptor close", .{ self.name, self.jid });
            self.jid = -1;
        } else if (self.jid > 0) {
            // Fall back to jail_remove()
            const rc = c.jail_remove(self.jid);
            if (rc < 0) {
                const err = getErrno();
                log.err("jail_remove({d}) failed: {s}", .{ self.jid, @tagName(err) });
                return error.RemoveFailed;
            }
            log.info("jail '{s}' (jid={d}) removed via jail_remove", .{ self.name, self.jid });
            // Close non-owning descriptor if present to avoid fd leak
            if (self.descriptor >= 0) {
                std.posix.close(self.descriptor);
                self.descriptor = -1;
            }
            self.jid = -1;
        } else {
            // Already destroyed — no-op
            log.debug("jail '{s}' already destroyed, skipping", .{self.name});
        }
    }

    fn destroyStub(_: *Jail) JailError!void {
        return error.UnsupportedPlatform;
    }

    /// Get the jail ID.
    pub fn getId(self: *const Jail) c_int {
        return self.jid;
    }

    /// Get the jail descriptor fd (-1 if not using descriptors).
    pub fn getDescriptor(self: *const Jail) c_int {
        return self.descriptor;
    }
};

// ============================================================
// Errors
// ============================================================

pub const JailError = error{
    UnsupportedPlatform,
    CreateFailed,
    RemoveFailed,
    QueryFailed,
    TooManyParams,
    AttachFailed,
    ExecFailed,
    ForkFailed,
    InvalidName,
};

// ============================================================
// Jail operations
// ============================================================

/// Execute jail_set() with the given iovec parameters and return the
/// created jail handle.  Separated from create() for function length.
fn executeJailSet(
    iovecs: *[MAX_PARAMS * 2]std.posix.iovec,
    niov: usize,
    flags: c_int,
    config: JailConfig,
    desc_val: *c_int,
    errmsg_buf: *[256]u8,
) JailError!Jail {
    log.info("creating jail '{s}' at '{s}' with {d} params, flags=0x{x}", .{
        config.name,
        config.path,
        niov,
        @as(u32, @intCast(flags)), // zlinter-disable-current-line no_bare_intcast — flags is c_int, display-only
    });

    const rc = c.jail_set(iovecs, @intCast(niov), flags); // zlinter-disable-current-line no_bare_intcast — niov bounded by small param array

    if (rc < 0) {
        const err = getErrno();
        if (errmsg_buf[0] != 0) {
            const msg = std.mem.sliceTo(errmsg_buf, 0);
            log.err("jail_set failed for '{s}': {s} ({s})", .{ config.name, msg, @tagName(err) });
        } else {
            log.err("jail_set failed for '{s}': {s}", .{ config.name, @tagName(err) });
        }
        return error.CreateFailed;
    }

    if (config.use_owning_descriptor) {
        // jail_set returns the JID as td_retval[0].
        // The descriptor fd was written back into desc_val by the kernel
        // via copyout() into the "desc" iovec value buffer.
        const jid = rc;
        const jd = desc_val.*;
        log.info("jail '{s}' created with owning descriptor fd={d}, jid={d}", .{ config.name, jd, jid });
        return .{
            .jid = jid,
            .descriptor = jd,
            .owning = true,
            .name = config.name,
        };
    } else {
        log.info("jail '{s}' created with jid={d}", .{ config.name, rc });
        return .{
            .jid = rc,
            .descriptor = -1,
            .owning = false,
            .name = config.name,
        };
    }
}

/// Create a new jail with the given configuration.
/// Returns a Jail handle. If use_owning_descriptor is true (default),
/// the jail will be automatically removed when the Jail is destroyed
/// or the process exits.
// zlinter-disable-next-line max_fn_body_lines — flat parameter-builder pattern, each section 2-8 lines
pub const create = if (is_freebsd) createImpl else createStub;

fn createStub(_: JailConfig) JailError!Jail {
    return error.UnsupportedPlatform;
}

/// Validate a jail name: must be non-empty, contain only alphanumeric
/// characters plus '.', '-', and '_', and have no null bytes or control
/// characters. Dotted names (e.g., "parent.child") are valid for child jails.
/// This matches the rctl.zig validation and prevents injection via jail_set().
fn validateJailName(name: [:0]const u8) JailError!void {
    if (name.len == 0) return error.InvalidName;
    for (name) |ch| {
        if (!std.ascii.isAlphanumeric(ch) and ch != '.' and ch != '-' and ch != '_') {
            log.err("invalid jail name '{s}' — contains forbidden character 0x{x:0>2}", .{ name, ch });
            return error.InvalidName;
        }
    }
}

// STYLE(5.1) exception: createImpl exceeds 150 lines (~200) but is a single
// jail parameter builder where all `const` values' addresses are taken via
// asBytes() and stored in the params array. These pointers MUST remain valid
// until jail_set() is called, which requires all declarations to live in the
// same stack frame. Extracting helper functions would risk dangling pointers.
fn createImpl(config: JailConfig) JailError!Jail {
    // Validate name: must be non-empty, alphanumeric + dot/hyphen/underscore,
    // and contain no null bytes. Dotted names (e.g., "parent.child") are valid
    // for child jails. This matches the validation in rctl.zig and prevents
    // injection of arbitrary data into jail_set() iovec parameters.
    try validateJailName(config.name);

    // Ensure required kernel modules are loaded before jail_set().
    // The "allow.mount.nullfs" parameter is only known to the kernel
    // when the nullfs module is present; without it, jail_set returns EINVAL.
    if (config.allow_mount_nullfs) {
        ensureKldLoaded("nullfs") catch {};
    }

    // Build parameter list
    var params: [MAX_PARAMS]JailParam = undefined;
    var n: usize = 0;

    // Pre-declare all c_int values whose addresses are taken via asBytes().
    // These MUST live in the same scope as `params` and the jail_set() call,
    // otherwise the pointers stored in params[].value dangle after the
    // declaring block exits. (C6 fix)
    const vnet_new: c_int = JAIL_SYS_NEW;
    const vnet_inherit: c_int = JAIL_SYS_INHERIT;
    const linux_new: c_int = JAIL_SYS_NEW;
    const linux_inherit: c_int = JAIL_SYS_INHERIT;
    const rsnum: c_int = config.devfs_ruleset;
    // enforce_statfs value — stored as c_int for iovec.
    // Must be declared here so the pointer remains valid until jail_set().
    // Clamped to [0, 2] (kernel only accepts 0, 1, or 2).
    const enforce_statfs_val: c_int = if (config.enforce_statfs) |es|
        @intCast(@min(es, 2)) // zlinter-disable-current-line no_bare_intcast — clamped to [0, 2]
    else
        2; // kernel default
    // children.max value — stored as c_int for iovec.
    // Must be declared here (not in a nested block) so the pointer
    // remains valid until jail_set() is called.
    // Clamp to max c_int to avoid @intCast panic on absurdly large values.
    const children_max_val: c_int = if (config.children_max) |cm|
        @intCast(@min(cm, @as(u32, @intCast(std.math.maxInt(c_int))))) // zlinter-disable-current-line no_bare_intcast — clamped to [0, maxInt(c_int)]
    else
        0;

    // Required parameters
    params[n] = .{ .name = "name", .value = std.mem.sliceAsBytes(config.name[0 .. config.name.len + 1]) };
    n += 1;

    params[n] = .{ .name = "path", .value = std.mem.sliceAsBytes(config.path[0 .. config.path.len + 1]) };
    n += 1;

    const hostname = config.hostname orelse config.name;
    params[n] = .{ .name = "host.hostname", .value = std.mem.sliceAsBytes(hostname[0 .. hostname.len + 1]) };
    n += 1;

    // VNET mode
    switch (config.vnet) {
        .new => {
            params[n] = .{ .name = "vnet", .value = std.mem.asBytes(&vnet_new) };
            n += 1;
        },
        .inherit => {
            params[n] = .{ .name = "vnet", .value = std.mem.asBytes(&vnet_inherit) };
            n += 1;
        },
        .disabled => {}, // omit vnet parameter entirely
    }

    // Linux binary compatibility mode (Linuxulator).
    // "linux" is an integer parameter like "vnet": JAIL_SYS_NEW creates a
    // per-jail Linux emulation environment, JAIL_SYS_INHERIT shares the parent's.
    switch (config.linux) {
        .new => {
            params[n] = .{ .name = "linux", .value = std.mem.asBytes(&linux_new) };
            n += 1;
        },
        .inherit => {
            params[n] = .{ .name = "linux", .value = std.mem.asBytes(&linux_inherit) };
            n += 1;
        },
        .disabled => {}, // omit linux parameter entirely
    }

    // linux.osrelease — the Linux kernel version reported to Linux binaries.
    // Only meaningful when linux != .disabled. The kernel stores this as a
    // null-terminated string in the prison's linux.osrelease field.
    if (config.linux_osrelease) |osrelease| {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{ .name = "linux.osrelease", .value = std.mem.sliceAsBytes(osrelease[0 .. osrelease.len + 1]) };
        n += 1;
    }

    // enforce_statfs — controls visibility of mount points inside the jail.
    // Default 2: jail can only see mounts within its own root.
    // Value 1: jail can see all mounts but paths are relativized to jail root.
    // Required for Linux compat — in-jail linprocfs/linsysfs mounts need level ≤ 1.
    if (config.enforce_statfs) |_| {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{ .name = "enforce_statfs", .value = std.mem.asBytes(&enforce_statfs_val) };
        n += 1;
    }

    // persist — keep jail alive even when no processes are running.
    // This is important because we set up the jail, then fork+exec into it.
    // Without persist, the jail could be auto-removed between creation and
    // the first process attaching to it.
    // Note: persist is a boolean flag (vfs_flagopt), value content is ignored.
    if (config.persist) {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{ .name = "persist", .value = &.{} };
        n += 1;
    }

    // children.max — maximum number of child jails allowed.
    // Pod jails must set this to at least the number of containers.
    // A value of 0 (kernel default) prevents any child jail creation.
    if (config.children_max) |_| {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{ .name = "children.max", .value = std.mem.asBytes(&children_max_val) };
        n += 1;
    }

    // Boolean allow.* permissions — jail uses vfs_flagopt which only checks
    // for name presence (value is ignored). Use "allow.X" to enable,
    // "allow.noX" to explicitly disable.
    //
    // Negation format (from kern_jail.c prison_add_allow):
    //   Simple:  allow.X       → allow.noX
    //   Nested:  allow.pfx.X   → allow.pfx.noX  (NOT allow.nopfx.X!)
    const bool_params = .{
        .{ "allow.raw_sockets", "allow.noraw_sockets", config.allow_raw_sockets },
        .{ "allow.mount", "allow.nomount", config.allow_mount },
        .{ "allow.mount.zfs", "allow.mount.nozfs", config.allow_mount_zfs },
        .{ "allow.mount.nullfs", "allow.mount.nonullfs", config.allow_mount_nullfs },
        .{ "allow.mount.devfs", "allow.mount.nodevfs", config.allow_mount_devfs },
        .{ "allow.mount.linprocfs", "allow.mount.nolinprocfs", config.allow_mount_linprocfs },
        .{ "allow.mount.linsysfs", "allow.mount.nolinsysfs", config.allow_mount_linsysfs },
        .{ "allow.mount.fdescfs", "allow.mount.nofdescfs", config.allow_mount_fdescfs },
        .{ "allow.mount.tmpfs", "allow.mount.notmpfs", config.allow_mount_tmpfs },
        .{ "allow.set_hostname", "allow.noset_hostname", config.allow_set_hostname },
    };

    inline for (bool_params) |bp| {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        // Use the "yes" name to enable, "no" name to disable.
        // Both are flag-style options (value content is ignored by vfs_flagopt).
        const name: [:0]const u8 = if (bp[2]) bp[0] else bp[1];
        params[n] = .{ .name = name, .value = &.{} };
        n += 1;
    }

    // Devfs ruleset — controls which /dev entries are visible inside the jail.
    // Passed as a raw c_int (4 bytes). Ruleset 4 = devfsrules_jail (standard).
    {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{ .name = "devfs_ruleset", .value = std.mem.asBytes(&rsnum) };
        n += 1;
    }

    // Jail metadata annotations (FreeBSD 16+, meta.* namespace)
    for (config.annotations) |ann| {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{
            .name = ann.key,
            .value = std.mem.sliceAsBytes(ann.value[0 .. ann.value.len + 1]),
        };
        n += 1;
    }

    // For jail descriptors, add the "desc" parameter.
    // The kernel requires a "desc" iovec when any descriptor flag is set
    // (JAIL_GET_DESC, JAIL_OWN_DESC, JAIL_USE_DESC, JAIL_AT_DESC).
    // For CREATE: pass desc=-1 as input; the kernel writes the allocated
    // descriptor fd back into this location via copyout().
    var desc_val: c_int = -1;
    if (config.use_owning_descriptor) {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{ .name = "desc", .value = std.mem.asBytes(&desc_val) };
        n += 1;
    }

    // Also add an errmsg buffer so the kernel can report detailed errors.
    var errmsg_buf: [256]u8 = undefined;
    @memset(&errmsg_buf, 0);
    {
        if (n >= MAX_PARAMS) return error.TooManyParams;
        params[n] = .{ .name = "errmsg", .value = &errmsg_buf };
        n += 1;
    }

    // Build iovec array — uses mutable iovec because the kernel writes
    // back into desc and errmsg buffers via copyout().
    var iovecs: [MAX_PARAMS * 2]std.posix.iovec = undefined;
    const niov = buildIovecs(params[0..n], &iovecs);

    // Flags: for CREATE with descriptors, use JAIL_GET_DESC | JAIL_OWN_DESC.
    // JAIL_USE_DESC is for looking up an EXISTING jail by descriptor (UPDATE),
    // not for creating new jails.  JAIL_GET_DESC requests the kernel to
    // allocate a new descriptor and write it back into the "desc" iovec.
    var flags: c_int = JAIL_CREATE;
    if (config.use_owning_descriptor) {
        flags |= JAIL_GET_DESC | JAIL_OWN_DESC;
    }

    return executeJailSet(&iovecs, niov, flags, config, &desc_val, &errmsg_buf);
}

/// Query the jail ID (JID) from a jail descriptor fd.
/// Uses jail_get() with JAIL_USE_DESC to look up the kernel-assigned JID
/// from a file descriptor returned by jail_set(JAIL_OWN_DESC).
///
/// The jail_get syscall returns the JID directly as its return value.
/// We pass "desc" as the input key (the fd) and an "errmsg" buffer
/// for diagnostics.
///
/// Returns the JID on success, or QueryFailed on error.
pub const queryJidFromDescriptor = if (is_freebsd) queryJidFromDescriptorImpl else queryJidFromDescriptorStub;

fn queryJidFromDescriptorStub(_: c_int) JailError!c_int {
    return error.UnsupportedPlatform;
}

fn queryJidFromDescriptorImpl(jd: c_int) JailError!c_int {
    // jail_get uses mutable iovecs (it writes output values back).
    var desc_val: c_int = jd;
    var errmsg_buf: [256]u8 = undefined;
    @memset(&errmsg_buf, 0);

    // jail_get uses the same iovec pair format as jail_set:
    // [name, value, name, value, ...]
    // For jail_get with JAIL_USE_DESC, we pass "desc" as input key.
    // The return value of jail_get() is the JID.
    var iovecs: [4]std.posix.iovec = .{
        // iov[0]: name "desc\0" (5 bytes including NUL)
        .{
            .base = @ptrCast(@constCast("desc\x00")),
            .len = 5,
        },
        // iov[1]: value = fd (c_int, 4 bytes)
        .{
            .base = @ptrCast(&desc_val),
            .len = @sizeOf(c_int),
        },
        // iov[2]: name "errmsg\0" (7 bytes including NUL)
        .{
            .base = @ptrCast(@constCast("errmsg\x00")),
            .len = 7,
        },
        // iov[3]: value = error message buffer
        .{
            .base = &errmsg_buf,
            .len = errmsg_buf.len,
        },
    };

    const rc = c.jail_get(&iovecs, 4, JAIL_USE_DESC);
    if (rc < 0) {
        const err = getErrno();
        if (errmsg_buf[0] != 0) {
            const msg = std.mem.sliceTo(&errmsg_buf, 0);
            log.err("jail_get(desc={d}) failed: {s} ({s})", .{ jd, msg, @tagName(err) });
        } else {
            log.err("jail_get(desc={d}) failed: {s}", .{ jd, @tagName(err) });
        }
        return error.QueryFailed;
    }

    log.info("jail descriptor fd={d} has jid={d}", .{ jd, rc });
    return rc;
}

/// Remove a jail by ID (without using descriptors).
pub const remove = if (is_freebsd) removeImpl else removeStub;

fn removeStub(_: c_int) JailError!void {
    return error.UnsupportedPlatform;
}

fn removeImpl(jid: c_int) JailError!void {
    const rc = c.jail_remove(jid);
    if (rc < 0) {
        const err = getErrno();
        log.err("jail_remove(jid={d}) failed: {s}", .{ jid, @tagName(err) });
        return error.RemoveFailed;
    }
}

/// Attach the current process to a jail by ID.
pub const attach = if (is_freebsd) attachImpl else attachStub;

fn attachStub(_: c_int) JailError!void {
    return error.UnsupportedPlatform;
}

fn attachImpl(jid: c_int) JailError!void {
    const rc = c.jail_attach(jid);
    if (rc < 0) {
        const err = getErrno();
        log.err("jail_attach(jid={d}) failed: {s}", .{ jid, @tagName(err) });
        return error.AttachFailed;
    }
}

/// Attach the current process to a jail by descriptor (FreeBSD 16+).
pub const attachByDescriptor = if (is_freebsd) attachByDescriptorImpl else attachByDescriptorStub;

fn attachByDescriptorStub(_: c_int) JailError!void {
    return error.UnsupportedPlatform;
}

fn attachByDescriptorImpl(jd: c_int) JailError!void {
    const rc = c.jail_attach_jd(jd);
    if (rc < 0) {
        const err = getErrno();
        log.err("jail_attach_jd(desc={d}) failed: {s}", .{ jd, @tagName(err) });
        return error.AttachFailed;
    }
}

/// Remove a jail by descriptor (FreeBSD 16+).
pub const removeByDescriptor = if (is_freebsd) removeByDescriptorImpl else removeByDescriptorStub;

fn removeByDescriptorStub(_: c_int) JailError!void {
    return error.UnsupportedPlatform;
}

fn removeByDescriptorImpl(jd: c_int) JailError!void {
    const rc = c.jail_remove_jd(jd);
    if (rc < 0) {
        const err = getErrno();
        log.err("jail_remove_jd(desc={d}) failed: {s}", .{ jd, @tagName(err) });
        return error.RemoveFailed;
    }
}

// ============================================================
// Process execution inside jails
// ============================================================

/// Configuration for executing a process inside a jail.
pub const ExecConfig = struct {
    /// Program to execute (absolute path within the jail rootfs).
    program: [*:0]const u8,
    /// Arguments (argv). argv[0] is conventionally the program name.
    /// If null, argv will be set to just the program path.
    argv: ?[*:null]const ?[*:0]const u8 = null,
    /// Environment variables (envp). If null, uses a minimal default environment.
    envp: ?[*:null]const ?[*:0]const u8 = null,
    /// Working directory inside the jail. If null, defaults to "/".
    working_dir: ?[*:0]const u8 = null,
    /// File descriptor for stdout redirection. -1 means inherit.
    stdout_fd: std.posix.fd_t = -1,
    /// File descriptor for stderr redirection. -1 means inherit.
    stderr_fd: std.posix.fd_t = -1,
    /// File descriptor for stdin redirection. -1 means inherit.
    stdin_fd: std.posix.fd_t = -1,
    /// User ID to run the process as. null means run as root (uid 0).
    uid: ?std.posix.uid_t = null,
    /// Group ID to run the process as. null means run as root (gid 0).
    gid: ?std.posix.gid_t = null,
    /// Batch2b-4: Supplementary group IDs (from OCI additionalGids).
    /// null means don't call setgroups. Empty slice means clear supplementary groups.
    additional_gids: ?[]const std.posix.gid_t = null,
};

/// Result of waiting for a jail process.
pub const WaitResult = union(enum) {
    /// Process exited normally with this exit code.
    exited: u8,
    /// Process was killed by a signal.
    signaled: u32,
    /// Process was stopped by a signal.
    stopped: u32,
    /// Unknown status.
    unknown: u32,

    /// Returns true if the process exited with code 0.
    pub fn success(self: WaitResult) bool {
        return switch (self) {
            .exited => |code| code == 0,
            else => false,
        };
    }

    /// Returns an exit code for reporting (0 for success, signal+128 convention, etc.)
    pub fn exitCode(self: WaitResult) i32 {
        return switch (self) {
            .exited => |code| @as(i32, code),
            .signaled => |sig| @as(i32, @intCast(sig)) + 128, // zlinter-disable-current-line no_bare_intcast — signal (u8) always fits i32
            .stopped => |sig| @as(i32, @intCast(sig)) + 128, // zlinter-disable-current-line no_bare_intcast — signal (u8) always fits i32
            .unknown => |raw| @bitCast(raw),
        };
    }

    fn fromRawStatus(status: u32) WaitResult {
        if (std.posix.W.IFEXITED(status)) {
            return .{ .exited = std.posix.W.EXITSTATUS(status) };
        } else if (std.posix.W.IFSIGNALED(status)) {
            return .{ .signaled = std.posix.W.TERMSIG(status) };
        } else if (std.posix.W.IFSTOPPED(status)) {
            return .{ .stopped = std.posix.W.STOPSIG(status) };
        } else {
            return .{ .unknown = status };
        }
    }
};

/// Handle to a process running inside a jail.
pub const JailProcess = struct {
    /// Child process PID.
    pid: std.posix.pid_t,
    /// Jail ID the process is attached to.
    jid: c_int,
    /// Cached wait result (set after wait completes).
    result: ?WaitResult = null,

    /// Block until the process exits. Returns the wait result.
    pub fn wait(self: *JailProcess) WaitResult {
        if (self.result) |r| return r;

        const w = std.posix.waitpid(self.pid, 0);
        const r = WaitResult.fromRawStatus(w.status);
        self.result = r;
        log.info("jail process pid={d} jid={d} exited: {s} code={d}", .{
            self.pid,
            self.jid,
            @tagName(r),
            r.exitCode(),
        });
        return r;
    }

    /// Non-blocking check: returns the wait result if the process has
    /// exited, or null if it's still running.
    pub const tryWait = if (is_freebsd) tryWaitImpl else tryWaitStub;

    fn tryWaitStub(_: *JailProcess) ?WaitResult {
        return null;
    }

    fn tryWaitImpl(self: *JailProcess) ?WaitResult {
        if (self.result) |r| return r;

        // Use waitpid with WNOHANG via raw syscall since std.posix.waitpid
        // doesn't support flags on all platforms consistently.
        const w = std.posix.waitpid(self.pid, std.c.W.NOHANG);
        if (w.pid == 0) {
            // Process still running
            return null;
        }
        const r = WaitResult.fromRawStatus(w.status);
        self.result = r;
        log.info("jail process pid={d} jid={d} exited: {s} code={d}", .{
            self.pid,
            self.jid,
            @tagName(r),
            r.exitCode(),
        });
        return r;
    }

    /// Send a signal to the process.
    /// Handles the race between checking `result` and the process exiting:
    /// if the process has already exited (ESRCH), this is a no-op rather
    /// than an error, preventing signals from being sent to recycled PIDs.
    pub fn kill(self: *const JailProcess, sig: u8) (error{PermissionDenied} || std.posix.UnexpectedError)!void {
        if (self.result != null) return; // already reaped
        std.posix.kill(self.pid, sig) catch |err| switch (err) {
            error.ProcessNotFound => return, // process exited between check and kill
            error.PermissionDenied => return error.PermissionDenied,
            error.Unexpected => return error.Unexpected,
        };
    }

    /// Send SIGTERM to gracefully terminate the process.
    pub fn terminate(self: *const JailProcess) (error{PermissionDenied} || std.posix.UnexpectedError)!void {
        try self.kill(std.posix.SIG.TERM);
    }

    /// Send SIGKILL to forcefully kill the process.
    pub fn forceKill(self: *const JailProcess) (error{PermissionDenied} || std.posix.UnexpectedError)!void {
        try self.kill(std.posix.SIG.KILL);
    }
};

/// Default minimal environment for jail processes.
const default_envp: [*:null]const ?[*:0]const u8 = &[_:null]?[*:0]const u8{
    "PATH=/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin",
    "HOME=/root",
    "TERM=xterm",
};

/// Default argv when none is provided (just the program name).
/// This is a sentinel-terminated array with just one null at the end.
fn makeDefaultArgv(program: [*:0]const u8) [2]?[*:0]const u8 {
    return .{ program, null };
}

/// Fork a child process, attach it to a jail, and exec a program.
///
/// The parent process returns a `JailProcess` handle that can be used
/// to monitor and wait for the child. The child process replaces itself
/// with the specified program via execve.
///
/// This function uses jail_attach() (by JID) to enter the jail. For
/// jail-descriptor-based attachment, use execInJailByDescriptor().
///
/// IMPORTANT: All arguments must be prepared before calling this function.
/// No allocations happen between fork() and exec() (async-signal-safety).
// zlinter-disable-next-line max_fn_body_lines — fork/exec child block requires async-signal-safety, cannot extract
pub const exec = if (is_freebsd) execImpl else execStub;

fn execStub(_: c_int, _: ExecConfig) JailError!JailProcess {
    return error.UnsupportedPlatform;
}

fn execImpl(jid: c_int, config: ExecConfig) JailError!JailProcess {
    // Pre-compute argv and envp before fork (no allocation after fork)
    var default_argv_buf = makeDefaultArgv(config.program);
    const argv: [*:null]const ?[*:0]const u8 = if (config.argv) |a|
        a
    else
        @ptrCast(&default_argv_buf);

    const envp: [*:null]const ?[*:0]const u8 = config.envp orelse default_envp;

    // Create an error pipe for the child to report exec failures back
    // to the parent. The pipe is CLOEXEC so it auto-closes on successful exec.
    const err_pipe = std.posix.pipe2(.{ .CLOEXEC = true }) catch {
        return error.ExecFailed;
    };

    const child_pid = std.posix.fork() catch {
        std.posix.close(err_pipe[0]);
        std.posix.close(err_pipe[1]);
        return error.ForkFailed;
    };

    if (child_pid == 0) {
        // === CHILD PROCESS ===
        // Only async-signal-safe operations from here until exec.
        std.posix.close(err_pipe[0]); // close read end

        // Relocate err_pipe[1] above stdio range (fd > 2) so that dup2 calls
        // for stdin/stdout/stderr cannot overwrite our error-reporting pipe.
        const err_fd = relocateAboveStdio(err_pipe[1]);
        if (err_fd < 0) std.posix.exit(127);

        // Step 1: Attach to the jail
        const attach_rc = c.jail_attach(jid);
        if (attach_rc < 0) {
            writeExecError(err_fd, 1);
            std.posix.exit(127);
        }

        // Step 2: chdir to working directory (inside the jail)
        const workdir = config.working_dir orelse "/";
        std.posix.chdirZ(workdir) catch {
            writeExecError(err_fd, 2);
            std.posix.exit(127);
        };

        // Step 3: Redirect stdio if requested
        // After dup2, close the original fd to avoid leaking it into the exec'd process.
        if (config.stdin_fd >= 0) {
            std.posix.dup2(config.stdin_fd, std.posix.STDIN_FILENO) catch {
                writeExecError(err_fd, 3);
                std.posix.exit(127);
            };
        }
        if (config.stdout_fd >= 0) {
            std.posix.dup2(config.stdout_fd, std.posix.STDOUT_FILENO) catch {
                writeExecError(err_fd, 4);
                std.posix.exit(127);
            };
        }
        if (config.stderr_fd >= 0) {
            std.posix.dup2(config.stderr_fd, std.posix.STDERR_FILENO) catch {
                writeExecError(err_fd, 5);
                std.posix.exit(127);
            };
        }
        // Close original fds now that they've been dup'd to 0/1/2.
        // Skip if fd is already one of the stdio fds (no-op dup2).
        // Close stdin_fd first, then stdout_fd if different, then stderr_fd if different from both.
        if (config.stdin_fd > std.posix.STDERR_FILENO) {
            std.posix.close(config.stdin_fd);
        }
        if (config.stdout_fd > std.posix.STDERR_FILENO and config.stdout_fd != config.stdin_fd) {
            std.posix.close(config.stdout_fd);
        }
        if (config.stderr_fd > std.posix.STDERR_FILENO and config.stderr_fd != config.stdin_fd and config.stderr_fd != config.stdout_fd) {
            std.posix.close(config.stderr_fd);
        }

        // Step 4: Set GID and UID if specified (must set GID before dropping UID)
        if (config.gid) |gid| {
            std.posix.setgid(gid) catch {
                writeExecError(err_fd, 7);
                std.posix.exit(127);
            };
        }
        // Batch2b-4: Set supplementary groups if specified (after setgid, before setuid).
        // Uses C setgroups() since Zig std.posix doesn't have it cross-platform.
        if (config.additional_gids) |gids| {
            const c_setgroups = struct {
                extern "c" fn setgroups(ngroups: c_int, gidset: [*]const std.posix.gid_t) c_int;
            };
            const ngroups: c_int = if (gids.len <= std.math.maxInt(c_int))
                @intCast(gids.len)
            else
                0;
            if (c_setgroups.setgroups(ngroups, gids.ptr) < 0) {
                writeExecError(err_fd, 9); // stage 9 = setgroups
                std.posix.exit(127);
            }
        }
        if (config.uid) |uid| {
            std.posix.setuid(uid) catch {
                writeExecError(err_fd, 8);
                std.posix.exit(127);
            };
        }

        // Step 5: exec the program
        // execWithPathResolution handles both absolute and relative paths (with PATH lookup).
        // Only returns on error — on success, this replaces the process image
        // and the CLOEXEC error pipe is automatically closed.
        const exec_errno = execWithPathResolution(config.program, argv, envp);
        writeExecErrorWithErrno(err_fd, 6, exec_errno);
        // Do NOT log here — we are in the child process after fork().
        // log.err() is not async-signal-safe and can deadlock on mutex.
        std.posix.exit(127);
    }

    // === PARENT PROCESS ===
    std.posix.close(err_pipe[1]); // close write end

    // Check if the child reported an error before exec.
    // The error pipe is CLOEXEC, so a successful exec closes it and we read 0.
    // On failure, the child writes a 2-byte error: [stage, errno].
    var err_buf: [2]u8 = undefined;
    const bytes_read = std.posix.read(err_pipe[0], &err_buf) catch 0;
    std.posix.close(err_pipe[0]);

    if (bytes_read > 0) {
        // Child reported an error — wait for it to die
        _ = std.posix.waitpid(child_pid, 0);
        const stage = err_buf[0];
        const errno_val: u8 = if (bytes_read > 1) err_buf[1] else 0;
        log.err("jail exec failed in child at stage {d} (1=jail_attach, 2=chdir, 3=stdin, 4=stdout, 5=stderr, 6=exec, 7=setgid, 8=setuid, 9=setgroups), errno={d}", .{ stage, errno_val });
        return error.ExecFailed;
    }

    log.info("forked process pid={d} into jail jid={d}, program={s}", .{
        child_pid,
        jid,
        std.mem.span(config.program),
    });

    return JailProcess{
        .pid = child_pid,
        .jid = jid,
    };
}

/// Execute a process in a jail using jail descriptor (FreeBSD 16+).
// zlinter-disable-next-line max_fn_body_lines — fork/exec child block requires async-signal-safety, cannot extract
fn execByDescriptorImpl(jd: c_int, jid: c_int, config: ExecConfig) JailError!JailProcess {
    var default_argv_buf = makeDefaultArgv(config.program);
    const argv: [*:null]const ?[*:0]const u8 = if (config.argv) |a|
        a
    else
        @ptrCast(&default_argv_buf);

    const envp: [*:null]const ?[*:0]const u8 = config.envp orelse default_envp;

    const err_pipe = std.posix.pipe2(.{ .CLOEXEC = true }) catch {
        return error.ExecFailed;
    };

    const child_pid = std.posix.fork() catch {
        std.posix.close(err_pipe[0]);
        std.posix.close(err_pipe[1]);
        return error.ForkFailed;
    };

    if (child_pid == 0) {
        // === CHILD ===
        std.posix.close(err_pipe[0]);

        // Relocate err_pipe[1] above stdio range (fd > 2) so that dup2 calls
        // for stdin/stdout/stderr cannot overwrite our error-reporting pipe.
        const err_fd = relocateAboveStdio(err_pipe[1]);
        if (err_fd < 0) std.posix.exit(127);

        // Attach via jail descriptor
        const attach_rc = c.jail_attach_jd(jd);
        if (attach_rc < 0) {
            writeExecError(err_fd, 1);
            std.posix.exit(127);
        }

        // Close the jail descriptor — child no longer needs it after attaching.
        // Without this, the fd leaks into the container process (no CLOEXEC),
        // potentially preventing jail destruction or allowing jail manipulation.
        // Deferred until after stdio dup2 to avoid closing a fd that might
        // collide with stdin/stdout/stderr (0/1/2) if jd happens to be low.

        const workdir = config.working_dir orelse "/";
        std.posix.chdirZ(workdir) catch {
            writeExecError(err_fd, 2);
            std.posix.exit(127);
        };

        if (config.stdin_fd >= 0) {
            std.posix.dup2(config.stdin_fd, std.posix.STDIN_FILENO) catch {
                writeExecError(err_fd, 3);
                std.posix.exit(127);
            };
        }
        if (config.stdout_fd >= 0) {
            std.posix.dup2(config.stdout_fd, std.posix.STDOUT_FILENO) catch {
                writeExecError(err_fd, 4);
                std.posix.exit(127);
            };
        }
        if (config.stderr_fd >= 0) {
            std.posix.dup2(config.stderr_fd, std.posix.STDERR_FILENO) catch {
                writeExecError(err_fd, 5);
                std.posix.exit(127);
            };
        }
        // Close original fds now that they've been dup'd to 0/1/2.
        if (config.stdin_fd > std.posix.STDERR_FILENO) {
            std.posix.close(config.stdin_fd);
        }
        if (config.stdout_fd > std.posix.STDERR_FILENO and config.stdout_fd != config.stdin_fd) {
            std.posix.close(config.stdout_fd);
        }
        if (config.stderr_fd > std.posix.STDERR_FILENO and config.stderr_fd != config.stdin_fd and config.stderr_fd != config.stdout_fd) {
            std.posix.close(config.stderr_fd);
        }

        // Now close the jail descriptor — safe because dup2 is done.
        // Guard against the (unlikely) case where jd is 0/1/2 after dup2,
        // and also avoid double-closing if jd matched one of the stdio redirect fds.
        if (jd > std.posix.STDERR_FILENO and jd != config.stdin_fd and jd != config.stdout_fd and jd != config.stderr_fd) {
            std.posix.close(jd);
        }

        // Set GID and UID if specified (must set GID before dropping UID)
        if (config.gid) |gid| {
            std.posix.setgid(gid) catch {
                writeExecError(err_fd, 7);
                std.posix.exit(127);
            };
        }
        // Batch2b-4: Set supplementary groups if specified (after setgid, before setuid).
        if (config.additional_gids) |gids| {
            const c_setgroups = struct {
                extern "c" fn setgroups(ngroups: c_int, gidset: [*]const std.posix.gid_t) c_int;
            };
            const ngroups: c_int = if (gids.len <= std.math.maxInt(c_int))
                @intCast(gids.len)
            else
                0;
            if (c_setgroups.setgroups(ngroups, gids.ptr) < 0) {
                writeExecError(err_fd, 9); // stage 9 = setgroups
                std.posix.exit(127);
            }
        }
        if (config.uid) |uid| {
            std.posix.setuid(uid) catch {
                writeExecError(err_fd, 8);
                std.posix.exit(127);
            };
        }

        // execWithPathResolution handles both absolute and relative paths (with PATH lookup).
        // Only returns on error — on success, the process image is replaced.
        // Do NOT log here — we are in the child process after fork().
        // log.err() is not async-signal-safe and can deadlock on mutex.
        const exec_errno2 = execWithPathResolution(config.program, argv, envp);
        writeExecErrorWithErrno(err_fd, 6, exec_errno2);
        std.posix.exit(127);
    }

    // === PARENT ===
    std.posix.close(err_pipe[1]);

    var err_buf_parent: [2]u8 = undefined;
    const bytes_read = std.posix.read(err_pipe[0], &err_buf_parent) catch 0;
    std.posix.close(err_pipe[0]);

    if (bytes_read > 0) {
        _ = std.posix.waitpid(child_pid, 0);
        const stage = err_buf_parent[0];
        const errno_val2: u8 = if (bytes_read > 1) err_buf_parent[1] else 0;
        log.err("jail exec (descriptor) failed in child at stage {d} (1=jail_attach, 2=chdir, 3=stdin, 4=stdout, 5=stderr, 6=exec, 7=setgid, 8=setuid, 9=setgroups), errno={d}", .{ stage, errno_val2 });
        return error.ExecFailed;
    }

    log.info("forked process pid={d} into jail jd={d}, program={s}", .{
        child_pid,
        jd,
        std.mem.span(config.program),
    });

    return JailProcess{
        .pid = child_pid,
        .jid = jid,
    };
}

fn execByDescriptorStub(jd: c_int, jid: c_int, config: ExecConfig) JailError!JailProcess {
    _ = jd;
    _ = jid;
    _ = config;
    return error.UnsupportedPlatform;
}

pub const execByDescriptor = if (is_freebsd) execByDescriptorImpl else execByDescriptorStub;

/// Write a single byte error code to the error pipe from the child process.
/// This is async-signal-safe (uses raw write).
/// Relocate a file descriptor to a value > STDERR_FILENO if it currently
/// occupies one of the stdio slots (0, 1, 2). This prevents dup2 calls for
/// stdin/stdout/stderr from inadvertently overwriting the error-reporting pipe.
/// The new fd inherits CLOEXEC via F_DUPFD_CLOEXEC. Returns the (possibly new) fd,
/// or -1 on failure (async-signal-safe: only uses dup/close syscalls).
fn relocateAboveStdio(fd: std.posix.fd_t) std.posix.fd_t {
    if (fd > std.posix.STDERR_FILENO) return fd;
    // F_DUPFD_CLOEXEC: duplicate to lowest available fd >= STDERR_FILENO+1
    const new_fd_raw = std.posix.fcntl(fd, std.posix.F.DUPFD_CLOEXEC, @as(usize, std.posix.STDERR_FILENO + 1)) catch return -1;
    const new_fd: std.posix.fd_t = std.math.cast(std.posix.fd_t, new_fd_raw) orelse return -1;
    std.posix.close(fd);
    return new_fd;
}

fn writeExecError(fd: std.posix.fd_t, stage: u8) void {
    writeExecErrorWithErrno(fd, stage, 0);
}

fn writeExecErrorWithErrno(fd: std.posix.fd_t, stage: u8, errno_val: u8) void {
    const buf = [_]u8{ stage, errno_val };
    _ = std.posix.write(fd, &buf) catch {}; // zlinter-disable-current-line no_swallow_error — child process after fork; best-effort pipe write, cannot log/propagate
}

/// Execute a program with PATH resolution for non-absolute commands.
/// For absolute paths, directly calls execveZ. For relative paths, searches PATH
/// and tries each directory until one succeeds. This function only returns on error;
/// on success, the process image is replaced.
/// Returns the last errno value from execve (as a u8) for error reporting.
fn execWithPathResolution(
    program: [*:0]const u8,
    argv: [*:null]const ?[*:0]const u8,
    envp: [*:null]const ?[*:0]const u8,
) u8 {
    const program_slice = std.mem.span(program);

    // If absolute path, exec directly
    if (program_slice.len > 0 and program_slice[0] == '/') {
        return tryExecve(program, argv, envp);
    }

    // Relative path: search PATH from environment
    // Extract PATH from envp
    var path_value: ?[]const u8 = null;
    var i: usize = 0;
    while (envp[i]) |env_entry| : (i += 1) {
        const env_str = std.mem.span(env_entry);
        if (std.mem.startsWith(u8, env_str, "PATH=")) {
            path_value = env_str[5..];
            break;
        }
    }

    // If no PATH, try default PATH
    const path = path_value orelse "/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin";

    // Buffer for constructing full paths (stack allocation, async-signal-safe)
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    var last_errno: u8 = 0;

    // Iterate through PATH directories
    var path_iter = std.mem.splitScalar(u8, path, ':');
    while (path_iter.next()) |dir| {
        if (dir.len == 0) continue;

        // Construct: dir + "/" + program + "\0"
        const full_path_len = dir.len + 1 + program_slice.len;
        if (full_path_len >= path_buf.len) continue; // path too long

        @memcpy(path_buf[0..dir.len], dir);
        path_buf[dir.len] = '/';
        @memcpy(path_buf[dir.len + 1 ..][0..program_slice.len], program_slice);
        path_buf[full_path_len] = 0;

        const full_path: [*:0]const u8 = @ptrCast(path_buf[0..full_path_len :0].ptr);

        // Try to exec this path - if it returns, the exec failed
        // (ENOENT, EACCES, etc.), so continue to next PATH entry
        last_errno = tryExecve(full_path, argv, envp);
        // execveZ never returns on success, only on error
    }

    // If we get here, all PATH entries failed. Try the program name directly
    // as a last resort (handles "./program" case).
    last_errno = tryExecve(program, argv, envp);
    return last_errno;
}

/// Try to execve and return the errno code on failure. Only returns on error.
fn tryExecve(
    program: [*:0]const u8,
    argv: [*:null]const ?[*:0]const u8,
    envp: [*:null]const ?[*:0]const u8,
) u8 {
    // execveZ only returns on failure (returns ExecveError directly, not an error union).
    // On success, the process image is replaced and this function never returns.
    const err = std.posix.execveZ(program, argv, envp);
    return execveErrno(err);
}

/// Map execve Zig error to a numeric errno for error reporting over the pipe.
fn execveErrno(err: std.posix.ExecveError) u8 {
    return switch (err) {
        error.FileNotFound => 2, // ENOENT
        error.AccessDenied => 13, // EACCES
        error.PermissionDenied => 13, // EACCES (or EPERM=1)
        error.InvalidExe => 8, // ENOEXEC
        error.SystemResources => 12, // ENOMEM
        error.NameTooLong => 63, // ENAMETOOLONG
        error.NotDir => 20, // ENOTDIR
        error.FileBusy => 26, // ETXTBSY
        error.FileSystem => 5, // EIO
        error.IsDir => 21, // EISDIR
        error.ProcessFdQuotaExceeded => 24, // EMFILE
        error.SystemFdQuotaExceeded => 23, // ENFILE
        error.Unexpected => 255,
    };
}

// ============================================================
// Filesystem mount operations -- re-exported from jail_mounts.zig
// ============================================================

pub const mountDevfs = jail_mounts.mountDevfs;
pub const unmountDevfs = jail_mounts.unmountDevfs;
pub const mountNullfs = jail_mounts.mountNullfs;
pub const unmountNullfs = jail_mounts.unmountNullfs;
pub const mountLinprocfs = jail_mounts.mountLinprocfs;
pub const unmountLinprocfs = jail_mounts.unmountLinprocfs;
pub const mountLinsysfs = jail_mounts.mountLinsysfs;
pub const unmountLinsysfs = jail_mounts.unmountLinsysfs;
pub const mountLindevfs = jail_mounts.mountLindevfs;
pub const unmountLindevfs = jail_mounts.unmountLindevfs;
pub const mountFdescfs = jail_mounts.mountFdescfs;
pub const unmountFdescfs = jail_mounts.unmountFdescfs;
pub const mountTmpfsShm = jail_mounts.mountTmpfsShm;
pub const unmountTmpfsShm = jail_mounts.unmountTmpfsShm;
pub const mountLinuxCompat = jail_mounts.mountLinuxCompat;
pub const unmountLinuxCompat = jail_mounts.unmountLinuxCompat;
pub const ensureLinuxEmulation = jail_mounts.ensureLinuxEmulation;
pub const LinuxEmulationError = jail_mounts.LinuxEmulationError;


/// Watch for jail events using kqueue.
/// Returns a kqueue fd configured to monitor jail lifecycle events.
pub const JailMonitor = struct {
    kq: c_int,

    fn initImpl() (error{UnsupportedPlatform} || std.posix.KQueueError)!JailMonitor {
        const kq = try std.posix.kqueue();
        return .{ .kq = kq };
    }

    fn initStub() (error{UnsupportedPlatform} || std.posix.KQueueError)!JailMonitor {
        return error.UnsupportedPlatform;
    }

    pub const init = if (is_freebsd) initImpl else initStub;

    /// Register interest in events on a jail descriptor.
    pub fn watchDescriptor(self: *JailMonitor, jd: c_int, fflags: u32) (error{InvalidDescriptor} || std.posix.KEventError)!void {
        if (jd < 0) return error.InvalidDescriptor;
        var changelist = [_]std.posix.Kevent{.{
            .ident = @intCast(jd), // zlinter-disable-current-line no_bare_intcast — bounded >= 0 by check above
            .filter = EVFILT_JAILDESC,
            .flags = std.c.EV.ADD | std.c.EV.ENABLE,
            .fflags = fflags,
            .data = 0,
            .udata = 0,
        }};

        _ = try std.posix.kevent(self.kq, &changelist, &.{}, null);
    }

    /// Wait for jail events. Returns the number of events received.
    pub fn poll(self: *JailMonitor, events: []std.posix.Kevent) std.posix.KEventError!usize {
        const n = try std.posix.kevent(self.kq, &.{}, events, null);
        return n;
    }

    pub fn deinit(self: *JailMonitor) void {
        if (self.kq >= 0) {
            std.posix.close(self.kq);
            self.kq = -1;
        }
    }
};

// ============================================================
// Tests
// ============================================================

test "jail constants match FreeBSD 16 values" {
    try std.testing.expectEqual(@as(c_int, 0x01), JAIL_CREATE);
    try std.testing.expectEqual(@as(c_int, 0x02), JAIL_UPDATE);
    try std.testing.expectEqual(@as(c_int, 0x04), JAIL_ATTACH);
    try std.testing.expectEqual(@as(c_int, 0x10), JAIL_USE_DESC);
    try std.testing.expectEqual(@as(c_int, 0x80), JAIL_OWN_DESC);
    try std.testing.expectEqual(@as(i16, -14), EVFILT_JAIL);
    try std.testing.expectEqual(@as(i16, -15), EVFILT_JAILDESC);
    try std.testing.expectEqual(@as(u32, 0x80000000), NOTE_JAIL_CHILD);
    try std.testing.expectEqual(@as(u32, 0x10000000), NOTE_JAIL_REMOVE);
}

test "JailConfig defaults" {
    const cfg = JailConfig{
        .name = "test",
        .path = "/jail/test",
    };
    try std.testing.expect(cfg.vnet == .new);
    try std.testing.expect(cfg.persist == true);
    try std.testing.expect(cfg.children_max == null);
    try std.testing.expect(cfg.use_owning_descriptor == true);
    try std.testing.expect(cfg.allow_raw_sockets == false);
    try std.testing.expect(cfg.allow_mount_devfs == true);
    try std.testing.expect(cfg.annotations.len == 0);
    try std.testing.expectEqual(@as(c_int, 4), cfg.devfs_ruleset);
}

test "buildIovecs produces correct layout" {
    const params = [_]JailParam{
        .{ .name = "name", .value = "test\x00" },
        .{ .name = "path", .value = "/jail\x00" },
    };
    var iovecs: [MAX_PARAMS * 2]std.posix.iovec = undefined;
    const n = buildIovecs(&params, &iovecs);
    // 2 params * 2 iovecs each = 4
    try std.testing.expectEqual(@as(usize, 4), n);
    // First iovec is "name\0" (5 bytes)
    try std.testing.expectEqual(@as(usize, 5), iovecs[0].len);
    // Second iovec is "test\0" (5 bytes)
    try std.testing.expectEqual(@as(usize, 5), iovecs[1].len);
}

test "WaitResult.success" {
    const exited_ok = WaitResult{ .exited = 0 };
    try std.testing.expect(exited_ok.success());

    const exited_err = WaitResult{ .exited = 1 };
    try std.testing.expect(!exited_err.success());

    const signaled = WaitResult{ .signaled = 9 };
    try std.testing.expect(!signaled.success());
}

test "WaitResult.exitCode" {
    const exited_ok = WaitResult{ .exited = 0 };
    try std.testing.expectEqual(@as(i32, 0), exited_ok.exitCode());

    const exited_42 = WaitResult{ .exited = 42 };
    try std.testing.expectEqual(@as(i32, 42), exited_42.exitCode());

    // Signal 9 (SIGKILL) → 128 + 9 = 137
    const signaled_9 = WaitResult{ .signaled = 9 };
    try std.testing.expectEqual(@as(i32, 137), signaled_9.exitCode());
}

test "ExecConfig defaults" {
    const cfg = ExecConfig{
        .program = "/bin/sh",
    };
    try std.testing.expect(cfg.argv == null);
    try std.testing.expect(cfg.envp == null);
    try std.testing.expect(cfg.working_dir == null);
    try std.testing.expectEqual(@as(std.posix.fd_t, -1), cfg.stdout_fd);
    try std.testing.expectEqual(@as(std.posix.fd_t, -1), cfg.stderr_fd);
    try std.testing.expectEqual(@as(std.posix.fd_t, -1), cfg.stdin_fd);
    try std.testing.expect(cfg.uid == null);
    try std.testing.expect(cfg.gid == null);
}

test "JailProcess initial state" {
    const proc = JailProcess{
        .pid = 12345,
        .jid = 42,
    };
    try std.testing.expectEqual(@as(std.posix.pid_t, 12345), proc.pid);
    try std.testing.expectEqual(@as(c_int, 42), proc.jid);
    try std.testing.expect(proc.result == null);
}

test "default_envp is null-terminated" {
    // Verify the default envp array has the expected entries
    var count: usize = 0;
    var ptr = default_envp;
    while (ptr[0]) |entry| {
        _ = entry;
        count += 1;
        ptr = @ptrFromInt(@intFromPtr(ptr) + @sizeOf(?[*:0]const u8));
    }
    try std.testing.expectEqual(@as(usize, 3), count);
}

test "queryJidFromDescriptor returns UnsupportedPlatform on non-FreeBSD" {
    if (is_freebsd) return error.SkipZigTest;
    const result = queryJidFromDescriptor(3);
    try std.testing.expectError(error.UnsupportedPlatform, result);
}

test "Jail struct fields with descriptor and JID" {
    // Verify that a Jail with both descriptor and JID has correct fields
    const j = Jail{
        .jid = 42,
        .descriptor = 7,
        .owning = true,
        .name = "test-jail",
    };
    try std.testing.expectEqual(@as(c_int, 42), j.jid);
    try std.testing.expectEqual(@as(c_int, 7), j.descriptor);
    try std.testing.expect(j.owning);
    try std.testing.expectEqualStrings("test-jail", j.name);
}

test "JailConfig devfs_ruleset defaults to 4" {
    const cfg = JailConfig{
        .name = "test",
        .path = "/jail/test",
    };
    try std.testing.expectEqual(@as(c_int, 4), cfg.devfs_ruleset);
}

test "JailConfig devfs_ruleset can be overridden" {
    const cfg = JailConfig{
        .name = "test",
        .path = "/jail/test",
        .devfs_ruleset = 0,
    };
    try std.testing.expectEqual(@as(c_int, 0), cfg.devfs_ruleset);
}

test "VnetMode enum values" {
    // Verify all enum variants exist and are distinct
    const new_mode: VnetMode = .new;
    const inherit_mode: VnetMode = .inherit;
    const disabled_mode: VnetMode = .disabled;
    try std.testing.expect(new_mode != inherit_mode);
    try std.testing.expect(new_mode != disabled_mode);
    try std.testing.expect(inherit_mode != disabled_mode);
}

test "JailConfig for pod jail (parent)" {
    // Pod jails: vnet=new, persist, children.max > 0, path=/
    const cfg = JailConfig{
        .name = "pod-abc123",
        .path = "/",
        .vnet = .new,
        .persist = true,
        .children_max = 10,
        .use_owning_descriptor = true,
    };
    try std.testing.expect(cfg.vnet == .new);
    try std.testing.expect(cfg.persist == true);
    try std.testing.expectEqual(@as(?u32, 10), cfg.children_max);
    try std.testing.expectEqualStrings("/", cfg.path);
}

test "JailConfig for container jail (child)" {
    // Container jails: vnet=inherit, dotted name, own rootfs
    const cfg = JailConfig{
        .name = "pod-abc123.nginx",
        .path = "/jails/containers/pod-abc123-nginx",
        .vnet = .inherit,
        .persist = true,
        .children_max = null,
        .use_owning_descriptor = true,
    };
    try std.testing.expect(cfg.vnet == .inherit);
    try std.testing.expect(cfg.persist == true);
    try std.testing.expect(cfg.children_max == null);
    // Dotted name indicates child of "pod-abc123"
    try std.testing.expect(std.mem.indexOf(u8, cfg.name, ".") != null);
}

test "JAIL_SYS constants for VnetMode" {
    // Verify the constants match FreeBSD kernel values
    try std.testing.expectEqual(@as(c_int, 0), JAIL_SYS_DISABLE);
    try std.testing.expectEqual(@as(c_int, 1), JAIL_SYS_NEW);
    try std.testing.expectEqual(@as(c_int, 2), JAIL_SYS_INHERIT);
}


test "LinuxMode enum values" {
    // Verify all enum variants exist and are distinct
    const new_mode: LinuxMode = .new;
    const inherit_mode: LinuxMode = .inherit;
    const disabled_mode: LinuxMode = .disabled;
    try std.testing.expect(new_mode != inherit_mode);
    try std.testing.expect(new_mode != disabled_mode);
    try std.testing.expect(inherit_mode != disabled_mode);
}

test "JailConfig with Linuxulator params for Linux container" {
    // Linux container child jail: linux=new, osrelease, enforce_statfs=1
    const cfg = JailConfig{
        .name = "pod-abc123.buildkit",
        .path = "/jails/containers/pod-abc123-buildkit",
        .vnet = .inherit,
        .persist = true,
        .children_max = null,
        .allow_mount_devfs = true,
        .linux = .new,
        .linux_osrelease = "5.15.0",
        .enforce_statfs = 1,
        .allow_mount_linprocfs = true,
        .allow_mount_linsysfs = true,
        .allow_mount_fdescfs = true,
        .allow_mount_tmpfs = true,
        .use_owning_descriptor = true,
    };
    try std.testing.expect(cfg.linux == .new);
    try std.testing.expectEqualStrings("5.15.0", cfg.linux_osrelease.?);
    try std.testing.expectEqual(@as(?u32, 1), cfg.enforce_statfs);
    try std.testing.expect(cfg.allow_mount_linprocfs);
    try std.testing.expect(cfg.allow_mount_linsysfs);
    try std.testing.expect(cfg.allow_mount_fdescfs);
    try std.testing.expect(cfg.allow_mount_tmpfs);
}

test "JailConfig defaults have Linuxulator disabled" {
    const cfg = JailConfig{
        .name = "pod-abc123.nginx",
        .path = "/jails/containers/pod-abc123-nginx",
        .vnet = .inherit,
        .persist = true,
        .use_owning_descriptor = true,
    };
    try std.testing.expect(cfg.linux == .disabled);
    try std.testing.expect(cfg.linux_osrelease == null);
    try std.testing.expect(cfg.enforce_statfs == null);
    try std.testing.expect(!cfg.allow_mount_linprocfs);
    try std.testing.expect(!cfg.allow_mount_linsysfs);
    try std.testing.expect(!cfg.allow_mount_fdescfs);
    try std.testing.expect(!cfg.allow_mount_tmpfs);
}

test "JailConfig pod jail with Linux mount permissions for children" {
    // Pod jails need allow.mount.* for child jails to inherit
    const cfg = JailConfig{
        .name = "pod-abc123",
        .path = "/",
        .vnet = .new,
        .persist = true,
        .children_max = 3,
        .allow_mount_devfs = true,
        .allow_mount_linprocfs = true,
        .allow_mount_linsysfs = true,
        .allow_mount_fdescfs = true,
        .allow_mount_tmpfs = true,
        .use_owning_descriptor = true,
    };
    // Pod jail itself doesn't get linux=new (that's per-child)
    try std.testing.expect(cfg.linux == .disabled);
    // But does allow children to mount Linux-compat filesystems
    try std.testing.expect(cfg.allow_mount_linprocfs);
    try std.testing.expect(cfg.allow_mount_linsysfs);
}

