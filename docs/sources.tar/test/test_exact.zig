const std = @import("std");
const mem = std.mem;

pub fn main() !void {
    var gpa = std.heap.GeneralPurposeAllocator(.{}){};
    defer _ = gpa.deinit();
    const allocator = gpa.allocator();
    
    // Exact pattern from switch.zig line 199
    var my_list = std.ArrayList(u8).init(allocator);
    defer my_list.deinit();
    
    try my_list.append(65);
    std.debug.print("Success! Item: {d}\n", .{my_list.items[0]});
}
