const std = @import("std");

fn hexToBytes(comptime hex: []const u8, buf: []u8) void {
    var i: usize = 0;
    while (i < hex.len) : (i += 2) {
        buf[i / 2] = std.fmt.parseInt(u8, hex[i..i+2], 16) catch unreachable;
    }
}

pub fn main() !void {
    var key0: [32]u8 = undefined;
    hexToBytes("000306090c0f1215181b1e2124272a2d303336393c3f4245484b4e5154575a5d", &key0);
    
    std.debug.print("Parsed: ", .{});
    for (key0) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
    
    var expected: [32]u8 = undefined;
    for (&expected, 0..) |*b, i| {
        b.* = @intCast((i * 3) & 0xff);
    }
    
    std.debug.print("Expected: ", .{});
    for (expected) |b| std.debug.print("{x:0>2}", .{b});
    std.debug.print("\n", .{});
    
    if (std.mem.eql(u8, &key0, &expected)) {
        std.debug.print("MATCH!\n", .{});
    } else {
        std.debug.print("MISMATCH!\n", .{});
    }
}
